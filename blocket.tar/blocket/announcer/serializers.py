from . import models

from rest_framework import serializers


class PostSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Post
        fields = (
            'slug', 
            'title', 
            'created', 
            'last_updated', 
            'category', 
            'price', 
            'date_manufacturer', 
            'type', 
            'Brand', 
            'description', 
        )


