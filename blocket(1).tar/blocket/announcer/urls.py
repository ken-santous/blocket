from django.urls import path, include
from rest_framework import routers

from . import api
from . import views

router = routers.DefaultRouter()
router.register(r'post', api.PostViewSet)


urlpatterns = (
    # urls for Django Rest Framework API
    path('api/v1/', include(router.urls)),
)

urlpatterns += (
    # urls for Post
    path('announcer/post/', views.PostListView.as_view(), name='announcer_post_list'),
    path('announcer/post/create/', views.PostCreateView.as_view(), name='announcer_post_create'),
    path('announcer/post/detail/<slug:slug>/', views.PostDetailView.as_view(), name='announcer_post_detail'),
    path('announcer/post/update/<slug:slug>/', views.PostUpdateView.as_view(), name='announcer_post_update'),
)

