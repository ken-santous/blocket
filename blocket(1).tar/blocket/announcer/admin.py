from django.contrib import admin
from django import forms
from .models import Post

class PostAdminForm(forms.ModelForm):

    class Meta:
        model = Post
        fields = '__all__'


class PostAdmin(admin.ModelAdmin):
    form = PostAdminForm
    list_display = ['title', 'slug', 'created', 'last_updated', 'category', 'price', 'date_manufacturer', 'type', 'Brand', 'description']
    readonly_fields = ['title', 'slug', 'created', 'last_updated', 'category', 'price', 'date_manufacturer', 'type', 'Brand', 'description']

admin.site.register(Post, PostAdmin)


