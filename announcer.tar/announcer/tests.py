import unittest
from django.urls import reverse
from django.test import Client
from .models import Post
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType


def create_django_contrib_auth_models_user(**kwargs):
    defaults = {}
    defaults["username"] = "username"
    defaults["email"] = "username@tempurl.com"
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_django_contrib_auth_models_group(**kwargs):
    defaults = {}
    defaults["name"] = "group"
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_django_contrib_contenttypes_models_contenttype(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_post(**kwargs):
    defaults = {}
    defaults["title"] = "title"
    defaults["category"] = "category"
    defaults["price"] = "price"
    defaults["date_manufacturer"] = "date_manufacturer"
    defaults["type"] = "type"
    defaults["Brand"] = "Brand"
    defaults["description"] = "description"
    defaults.update(**kwargs)
    if "client" not in defaults:
        defaults["client"] = create_django_contrib_auth_models_user()
    return Post.objects.create(**defaults)


class PostViewTest(unittest.TestCase):
    '''
    Tests for Post
    '''
    def setUp(self):
        self.client = Client()

    def test_list_post(self):
        url = reverse('announcer_post_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_post(self):
        url = reverse('announcer_post_create')
        data = {
            "title": "title",
            "category": "category",
            "price": "price",
            "date_manufacturer": "date_manufacturer",
            "type": "type",
            "Brand": "Brand",
            "description": "description",
            "client": create_django_contrib_auth_models_user().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_post(self):
        post = create_post()
        url = reverse('announcer_post_detail', args=[post.slug,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_post(self):
        post = create_post()
        data = {
            "title": "title",
            "category": "category",
            "price": "price",
            "date_manufacturer": "date_manufacturer",
            "type": "type",
            "Brand": "Brand",
            "description": "description",
            "client": create_django_contrib_auth_models_user().pk,
        }
        url = reverse('announcer_post_update', args=[post.slug,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


