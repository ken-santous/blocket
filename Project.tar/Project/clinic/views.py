from django.views.generic import DetailView, ListView, UpdateView, CreateView
from .models import Person, Doctor, Nurse, Insurance, Visit, Bill, Treatment
from .forms import PersonForm, DoctorForm, NurseForm, InsuranceForm, VisitForm, BillForm, TreatmentForm


class PersonListView(ListView):
    model = Person


class PersonCreateView(CreateView):
    model = Person
    form_class = PersonForm


class PersonDetailView(DetailView):
    model = Person


class PersonUpdateView(UpdateView):
    model = Person
    form_class = PersonForm


class DoctorListView(ListView):
    model = Doctor


class DoctorCreateView(CreateView):
    model = Doctor
    form_class = DoctorForm


class DoctorDetailView(DetailView):
    model = Doctor


class DoctorUpdateView(UpdateView):
    model = Doctor
    form_class = DoctorForm


class NurseListView(ListView):
    model = Nurse


class NurseCreateView(CreateView):
    model = Nurse
    form_class = NurseForm


class NurseDetailView(DetailView):
    model = Nurse


class NurseUpdateView(UpdateView):
    model = Nurse
    form_class = NurseForm


class InsuranceListView(ListView):
    model = Insurance


class InsuranceCreateView(CreateView):
    model = Insurance
    form_class = InsuranceForm


class InsuranceDetailView(DetailView):
    model = Insurance


class InsuranceUpdateView(UpdateView):
    model = Insurance
    form_class = InsuranceForm


class VisitListView(ListView):
    model = Visit


class VisitCreateView(CreateView):
    model = Visit
    form_class = VisitForm


class VisitDetailView(DetailView):
    model = Visit


class VisitUpdateView(UpdateView):
    model = Visit
    form_class = VisitForm


class BillListView(ListView):
    model = Bill


class BillCreateView(CreateView):
    model = Bill
    form_class = BillForm


class BillDetailView(DetailView):
    model = Bill


class BillUpdateView(UpdateView):
    model = Bill
    form_class = BillForm


class TreatmentListView(ListView):
    model = Treatment


class TreatmentCreateView(CreateView):
    model = Treatment
    form_class = TreatmentForm


class TreatmentDetailView(DetailView):
    model = Treatment


class TreatmentUpdateView(UpdateView):
    model = Treatment
    form_class = TreatmentForm

