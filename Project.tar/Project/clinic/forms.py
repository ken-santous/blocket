from django import forms
from .models import Person, Doctor, Nurse, Insurance, Visit, Bill, Treatment


class PersonForm(forms.ModelForm):
    class Meta:
        model = Person
        fields = ['name', 'age']


class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = ['name', 'spicialty']


class NurseForm(forms.ModelForm):
    class Meta:
        model = Nurse
        fields = ['name']


class InsuranceForm(forms.ModelForm):
    class Meta:
        model = Insurance
        fields = ['name']


class VisitForm(forms.ModelForm):
    class Meta:
        model = Visit
        fields = ['title']


class BillForm(forms.ModelForm):
    class Meta:
        model = Bill
        fields = ['title']


class TreatmentForm(forms.ModelForm):
    class Meta:
        model = Treatment
        fields = ['name']


