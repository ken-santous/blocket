from . import models

from rest_framework import serializers


class PersonSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Person
        fields = (
            'slug', 
            'name', 
            'created', 
            'last_updated', 
            'age', 
        )


class DoctorSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Doctor
        fields = (
            'slug', 
            'name', 
            'created', 
            'last_updated', 
            'spicialty', 
        )


class NurseSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Nurse
        fields = (
            'slug', 
            'name', 
            'created', 
            'last_updated', 
        )


class InsuranceSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Insurance
        fields = (
            'slug', 
            'name', 
            'created', 
            'last_updated', 
        )


class VisitSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Visit
        fields = (
            'slug', 
            'title', 
            'created', 
            'last_updated', 
        )


class BillSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Bill
        fields = (
            'slug', 
            'title', 
            'created', 
            'last_updated', 
        )


class TreatmentSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Treatment
        fields = (
            'slug', 
            'name', 
            'created', 
            'last_updated', 
        )


