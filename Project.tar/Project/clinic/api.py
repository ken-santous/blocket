from . import models
from . import serializers
from rest_framework import viewsets, permissions


class PersonViewSet(viewsets.ModelViewSet):
    """ViewSet for the Person class"""

    queryset = models.Person.objects.all()
    serializer_class = serializers.PersonSerializer
    permission_classes = [permissions.IsAuthenticated]


class DoctorViewSet(viewsets.ModelViewSet):
    """ViewSet for the Doctor class"""

    queryset = models.Doctor.objects.all()
    serializer_class = serializers.DoctorSerializer
    permission_classes = [permissions.IsAuthenticated]


class NurseViewSet(viewsets.ModelViewSet):
    """ViewSet for the Nurse class"""

    queryset = models.Nurse.objects.all()
    serializer_class = serializers.NurseSerializer
    permission_classes = [permissions.IsAuthenticated]


class InsuranceViewSet(viewsets.ModelViewSet):
    """ViewSet for the Insurance class"""

    queryset = models.Insurance.objects.all()
    serializer_class = serializers.InsuranceSerializer
    permission_classes = [permissions.IsAuthenticated]


class VisitViewSet(viewsets.ModelViewSet):
    """ViewSet for the Visit class"""

    queryset = models.Visit.objects.all()
    serializer_class = serializers.VisitSerializer
    permission_classes = [permissions.IsAuthenticated]


class BillViewSet(viewsets.ModelViewSet):
    """ViewSet for the Bill class"""

    queryset = models.Bill.objects.all()
    serializer_class = serializers.BillSerializer
    permission_classes = [permissions.IsAuthenticated]


class TreatmentViewSet(viewsets.ModelViewSet):
    """ViewSet for the Treatment class"""

    queryset = models.Treatment.objects.all()
    serializer_class = serializers.TreatmentSerializer
    permission_classes = [permissions.IsAuthenticated]


