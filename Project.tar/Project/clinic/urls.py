from django.urls import path, include
from rest_framework import routers

from . import api
from . import views

router = routers.DefaultRouter()
router.register(r'person', api.PersonViewSet)
router.register(r'doctor', api.DoctorViewSet)
router.register(r'nurse', api.NurseViewSet)
router.register(r'insurance', api.InsuranceViewSet)
router.register(r'visit', api.VisitViewSet)
router.register(r'bill', api.BillViewSet)
router.register(r'treatment', api.TreatmentViewSet)


urlpatterns = (
    # urls for Django Rest Framework API
    path('api/v1/', include(router.urls)),
)

urlpatterns += (
    # urls for Person
    path('clinic/person/', views.PersonListView.as_view(), name='clinic_person_list'),
    path('clinic/person/create/', views.PersonCreateView.as_view(), name='clinic_person_create'),
    path('clinic/person/detail/<slug:slug>/', views.PersonDetailView.as_view(), name='clinic_person_detail'),
    path('clinic/person/update/<slug:slug>/', views.PersonUpdateView.as_view(), name='clinic_person_update'),
)

urlpatterns += (
    # urls for Doctor
    path('clinic/doctor/', views.DoctorListView.as_view(), name='clinic_doctor_list'),
    path('clinic/doctor/create/', views.DoctorCreateView.as_view(), name='clinic_doctor_create'),
    path('clinic/doctor/detail/<slug:slug>/', views.DoctorDetailView.as_view(), name='clinic_doctor_detail'),
    path('clinic/doctor/update/<slug:slug>/', views.DoctorUpdateView.as_view(), name='clinic_doctor_update'),
)

urlpatterns += (
    # urls for Nurse
    path('clinic/nurse/', views.NurseListView.as_view(), name='clinic_nurse_list'),
    path('clinic/nurse/create/', views.NurseCreateView.as_view(), name='clinic_nurse_create'),
    path('clinic/nurse/detail/<slug:slug>/', views.NurseDetailView.as_view(), name='clinic_nurse_detail'),
    path('clinic/nurse/update/<slug:slug>/', views.NurseUpdateView.as_view(), name='clinic_nurse_update'),
)

urlpatterns += (
    # urls for Insurance
    path('clinic/insurance/', views.InsuranceListView.as_view(), name='clinic_insurance_list'),
    path('clinic/insurance/create/', views.InsuranceCreateView.as_view(), name='clinic_insurance_create'),
    path('clinic/insurance/detail/<slug:slug>/', views.InsuranceDetailView.as_view(), name='clinic_insurance_detail'),
    path('clinic/insurance/update/<slug:slug>/', views.InsuranceUpdateView.as_view(), name='clinic_insurance_update'),
)

urlpatterns += (
    # urls for Visit
    path('clinic/visit/', views.VisitListView.as_view(), name='clinic_visit_list'),
    path('clinic/visit/create/', views.VisitCreateView.as_view(), name='clinic_visit_create'),
    path('clinic/visit/detail/<slug:slug>/', views.VisitDetailView.as_view(), name='clinic_visit_detail'),
    path('clinic/visit/update/<slug:slug>/', views.VisitUpdateView.as_view(), name='clinic_visit_update'),
)

urlpatterns += (
    # urls for Bill
    path('clinic/bill/', views.BillListView.as_view(), name='clinic_bill_list'),
    path('clinic/bill/create/', views.BillCreateView.as_view(), name='clinic_bill_create'),
    path('clinic/bill/detail/<slug:slug>/', views.BillDetailView.as_view(), name='clinic_bill_detail'),
    path('clinic/bill/update/<slug:slug>/', views.BillUpdateView.as_view(), name='clinic_bill_update'),
)

urlpatterns += (
    # urls for Treatment
    path('clinic/treatment/', views.TreatmentListView.as_view(), name='clinic_treatment_list'),
    path('clinic/treatment/create/', views.TreatmentCreateView.as_view(), name='clinic_treatment_create'),
    path('clinic/treatment/detail/<slug:slug>/', views.TreatmentDetailView.as_view(), name='clinic_treatment_detail'),
    path('clinic/treatment/update/<slug:slug>/', views.TreatmentUpdateView.as_view(), name='clinic_treatment_update'),
)

