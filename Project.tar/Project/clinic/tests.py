import unittest
from django.urls import reverse
from django.test import Client
from .models import Person, Doctor, Nurse, Insurance, Visit, Bill, Treatment
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType


def create_django_contrib_auth_models_user(**kwargs):
    defaults = {}
    defaults["username"] = "username"
    defaults["email"] = "username@tempurl.com"
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_django_contrib_auth_models_group(**kwargs):
    defaults = {}
    defaults["name"] = "group"
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_django_contrib_contenttypes_models_contenttype(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_person(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults["age"] = "age"
    defaults.update(**kwargs)
    return Person.objects.create(**defaults)


def create_doctor(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults["spicialty"] = "spicialty"
    defaults.update(**kwargs)
    return Doctor.objects.create(**defaults)


def create_nurse(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults.update(**kwargs)
    return Nurse.objects.create(**defaults)


def create_insurance(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults.update(**kwargs)
    return Insurance.objects.create(**defaults)


def create_visit(**kwargs):
    defaults = {}
    defaults["title"] = "title"
    defaults.update(**kwargs)
    return Visit.objects.create(**defaults)


def create_bill(**kwargs):
    defaults = {}
    defaults["title"] = "title"
    defaults.update(**kwargs)
    return Bill.objects.create(**defaults)


def create_treatment(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults.update(**kwargs)
    return Treatment.objects.create(**defaults)


class PersonViewTest(unittest.TestCase):
    '''
    Tests for Person
    '''
    def setUp(self):
        self.client = Client()

    def test_list_person(self):
        url = reverse('clinic_person_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_person(self):
        url = reverse('clinic_person_create')
        data = {
            "name": "name",
            "age": "age",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_person(self):
        person = create_person()
        url = reverse('clinic_person_detail', args=[person.slug,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_person(self):
        person = create_person()
        data = {
            "name": "name",
            "age": "age",
        }
        url = reverse('clinic_person_update', args=[person.slug,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DoctorViewTest(unittest.TestCase):
    '''
    Tests for Doctor
    '''
    def setUp(self):
        self.client = Client()

    def test_list_doctor(self):
        url = reverse('clinic_doctor_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_doctor(self):
        url = reverse('clinic_doctor_create')
        data = {
            "name": "name",
            "spicialty": "spicialty",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_doctor(self):
        doctor = create_doctor()
        url = reverse('clinic_doctor_detail', args=[doctor.slug,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_doctor(self):
        doctor = create_doctor()
        data = {
            "name": "name",
            "spicialty": "spicialty",
        }
        url = reverse('clinic_doctor_update', args=[doctor.slug,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class NurseViewTest(unittest.TestCase):
    '''
    Tests for Nurse
    '''
    def setUp(self):
        self.client = Client()

    def test_list_nurse(self):
        url = reverse('clinic_nurse_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_nurse(self):
        url = reverse('clinic_nurse_create')
        data = {
            "name": "name",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_nurse(self):
        nurse = create_nurse()
        url = reverse('clinic_nurse_detail', args=[nurse.slug,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_nurse(self):
        nurse = create_nurse()
        data = {
            "name": "name",
        }
        url = reverse('clinic_nurse_update', args=[nurse.slug,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class InsuranceViewTest(unittest.TestCase):
    '''
    Tests for Insurance
    '''
    def setUp(self):
        self.client = Client()

    def test_list_insurance(self):
        url = reverse('clinic_insurance_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_insurance(self):
        url = reverse('clinic_insurance_create')
        data = {
            "name": "name",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_insurance(self):
        insurance = create_insurance()
        url = reverse('clinic_insurance_detail', args=[insurance.slug,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_insurance(self):
        insurance = create_insurance()
        data = {
            "name": "name",
        }
        url = reverse('clinic_insurance_update', args=[insurance.slug,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class VisitViewTest(unittest.TestCase):
    '''
    Tests for Visit
    '''
    def setUp(self):
        self.client = Client()

    def test_list_visit(self):
        url = reverse('clinic_visit_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_visit(self):
        url = reverse('clinic_visit_create')
        data = {
            "title": "title",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_visit(self):
        visit = create_visit()
        url = reverse('clinic_visit_detail', args=[visit.slug,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_visit(self):
        visit = create_visit()
        data = {
            "title": "title",
        }
        url = reverse('clinic_visit_update', args=[visit.slug,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class BillViewTest(unittest.TestCase):
    '''
    Tests for Bill
    '''
    def setUp(self):
        self.client = Client()

    def test_list_bill(self):
        url = reverse('clinic_bill_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_bill(self):
        url = reverse('clinic_bill_create')
        data = {
            "title": "title",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_bill(self):
        bill = create_bill()
        url = reverse('clinic_bill_detail', args=[bill.slug,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_bill(self):
        bill = create_bill()
        data = {
            "title": "title",
        }
        url = reverse('clinic_bill_update', args=[bill.slug,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class TreatmentViewTest(unittest.TestCase):
    '''
    Tests for Treatment
    '''
    def setUp(self):
        self.client = Client()

    def test_list_treatment(self):
        url = reverse('clinic_treatment_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_treatment(self):
        url = reverse('clinic_treatment_create')
        data = {
            "name": "name",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_treatment(self):
        treatment = create_treatment()
        url = reverse('clinic_treatment_detail', args=[treatment.slug,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_treatment(self):
        treatment = create_treatment()
        data = {
            "name": "name",
        }
        url = reverse('clinic_treatment_update', args=[treatment.slug,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


