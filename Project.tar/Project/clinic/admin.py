from django.contrib import admin
from django import forms
from .models import Person, Doctor, Nurse, Insurance, Visit, Bill, Treatment

class PersonAdminForm(forms.ModelForm):

    class Meta:
        model = Person
        fields = '__all__'


class PersonAdmin(admin.ModelAdmin):
    form = PersonAdminForm
    list_display = ['name', 'slug', 'created', 'last_updated', 'age']
    readonly_fields = ['name', 'slug', 'created', 'last_updated', 'age']

admin.site.register(Person, PersonAdmin)


class DoctorAdminForm(forms.ModelForm):

    class Meta:
        model = Doctor
        fields = '__all__'


class DoctorAdmin(admin.ModelAdmin):
    form = DoctorAdminForm
    list_display = ['name', 'slug', 'created', 'last_updated', 'spicialty']
    readonly_fields = ['name', 'slug', 'created', 'last_updated', 'spicialty']

admin.site.register(Doctor, DoctorAdmin)


class NurseAdminForm(forms.ModelForm):

    class Meta:
        model = Nurse
        fields = '__all__'


class NurseAdmin(admin.ModelAdmin):
    form = NurseAdminForm
    list_display = ['name', 'slug', 'created', 'last_updated']
    readonly_fields = ['name', 'slug', 'created', 'last_updated']

admin.site.register(Nurse, NurseAdmin)


class InsuranceAdminForm(forms.ModelForm):

    class Meta:
        model = Insurance
        fields = '__all__'


class InsuranceAdmin(admin.ModelAdmin):
    form = InsuranceAdminForm
    list_display = ['name', 'slug', 'created', 'last_updated']
    readonly_fields = ['name', 'slug', 'created', 'last_updated']

admin.site.register(Insurance, InsuranceAdmin)


class VisitAdminForm(forms.ModelForm):

    class Meta:
        model = Visit
        fields = '__all__'


class VisitAdmin(admin.ModelAdmin):
    form = VisitAdminForm
    list_display = ['title', 'slug', 'created', 'last_updated']
    readonly_fields = ['title', 'slug', 'created', 'last_updated']

admin.site.register(Visit, VisitAdmin)


class BillAdminForm(forms.ModelForm):

    class Meta:
        model = Bill
        fields = '__all__'


class BillAdmin(admin.ModelAdmin):
    form = BillAdminForm
    list_display = ['title', 'slug', 'created', 'last_updated']
    readonly_fields = ['title', 'slug', 'created', 'last_updated']

admin.site.register(Bill, BillAdmin)


class TreatmentAdminForm(forms.ModelForm):

    class Meta:
        model = Treatment
        fields = '__all__'


class TreatmentAdmin(admin.ModelAdmin):
    form = TreatmentAdminForm
    list_display = ['name', 'slug', 'created', 'last_updated']
    readonly_fields = ['name', 'slug', 'created', 'last_updated']

admin.site.register(Treatment, TreatmentAdmin)


